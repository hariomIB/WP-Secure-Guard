<?php
define('WP_USE_THEMES', false);
define('WP_ADMIN', true);
require 'C:/wamp64/www/adosoil/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';
require_once ABSPATH . 'wp-admin/includes/update.php';

$up = get_site_transient('update_plugins');
$file = 'WP-Secure-Guard-main/wp-secure-guard.php';

echo "Update for $file:\n";
if (isset($up->response[$file])) {
    echo "Found update! Details:\n";
    print_r($up->response[$file]);
} else {
    echo "NO update in response.\n";
}
