<?php
define('WP_USE_THEMES', false);
define('WP_ADMIN', true);
require 'C:/wamp64/www/adosoil/wp-load.php';

$up = get_site_transient('update_plugins');

$plugin_file = 'WP-Secure-Guard-main/wp-secure-guard.php';

echo "Is in transient->response? " . (isset($up->response[$plugin_file]) ? 'YES' : 'NO') . "\n";
echo "Is in transient->no_update? " . (isset($up->no_update[$plugin_file]) ? 'YES' : 'NO') . "\n";
