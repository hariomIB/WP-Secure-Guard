<?php
define('WP_USE_THEMES', false);
define('WP_ADMIN', true);
require 'C:/wamp64/www/adosoil/wp-load.php';

// Force delete existing transients to simulate fresh check
delete_transient( WPSG_Updater::CACHE_KEY );
delete_site_transient( 'update_plugins' );

echo "Current installed WPSG_VERSION: " . WPSG_VERSION . "\n";
echo "Current plugin file: " . plugin_basename( WPSG_PLUGIN_FILE ) . "\n";

// Fetch remote version
$info = WPSG_Updater::get_remote_version_info( true );
echo "Fetched remote version: " . ($info ? $info['version'] : 'FAILED') . "\n";

// Now test check_for_update
$transient = get_site_transient( 'update_plugins' );
if ( ! is_object( $transient ) ) {
    $transient = new stdClass();
}
$transient->checked = array(
    plugin_basename( WPSG_PLUGIN_FILE ) => WPSG_VERSION,
);

$res = WPSG_Updater::check_for_update( $transient );

$key = plugin_basename( WPSG_PLUGIN_FILE );
echo "Is in transient->response[$key]? " . (isset($res->response[$key]) ? 'YES' : 'NO') . "\n";
if (isset($res->response[$key])) {
    echo "New version in response: " . $res->response[$key]->new_version . "\n";
    echo "Package URL: " . $res->response[$key]->package . "\n";
}
