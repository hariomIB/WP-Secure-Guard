<?php
define('WP_USE_THEMES', false);
define('WP_ADMIN', true);
require 'C:/wamp64/www/adosoil/wp-load.php';

$args = (object) array(
    'slug' => 'wp-secure-guard',
);

$res = WPSG_Updater::plugin_info(false, 'plugin_information', $args);
echo "Plugin info result:\n";
print_r($res);
